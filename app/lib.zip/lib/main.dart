// lib/main.dart

import 'package:flutter/material.dart';
import 'routes.dart';

void main() {
  runApp(const Team10App());
}

class Team10App extends StatelessWidget {
  const Team10App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Team 10 Restaurant App",
      debugShowCheckedModeBanner: false,
      initialRoute: AppRoutes.login,
      onGenerateRoute: AppRoutes.generateRoute,
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
        scaffoldBackgroundColor: Colors.white,
      ),
    );
  }
}
