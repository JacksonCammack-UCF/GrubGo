// lib/routes.dart

import 'package:flutter/material.dart';
import 'screens/LoginScreen.dart';
import 'screens/CardsScreen.dart';

class AppRoutes {
  static const String login = "/";
  static const String cards = "/cards";

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case login:
        return MaterialPageRoute(builder: (_) => LoginScreen());

      case cards:
        return MaterialPageRoute(builder: (_) => CardsScreen());

      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(
              child: Text("Route not found: ${settings.name}"),
            ),
          ),
        );
    }
  }
}
