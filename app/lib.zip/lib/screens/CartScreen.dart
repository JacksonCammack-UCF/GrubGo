// lib/screens/CartScreen.dart

import 'package:flutter/material.dart';
import '../utils/GlobalData.dart';

class CartScreen extends StatefulWidget {
  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  List<Map<String, dynamic>> cartItems = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadCart();
  }

  void loadCart() {
    setState(() {
      cartItems = List<Map<String, dynamic>>.from(GlobalData.cart);
      loading = false;
    });
  }

  double getSubtotal() {
    double subtotal = 0;

    for (var item in cartItems) {
      final double price = (item["price"] ?? 0).toDouble();
      final int qty = item["quantity"] ?? 1;
      subtotal += price * qty;
    }

    return subtotal;
  }

  double getTotal() => getSubtotal() * 1.06;

  bool hasOutOfStock() {
    return cartItems.any((item) => item["inStock"] == false);
  }

  void incrementQty(String id) {
    final index = GlobalData.cart.indexWhere((item) => item["_id"] == id);
    if (index >= 0) {
      GlobalData.cart[index]["quantity"]++;
      loadCart();
    }
  }

  void decrementQty(String id) {
    final index = GlobalData.cart.indexWhere((item) => item["_id"] == id);
    if (index >= 0) {
      final int q = GlobalData.cart[index]["quantity"];
      if (q <= 1) {
        GlobalData.removeFromCart(id);
      } else {
        GlobalData.cart[index]["quantity"] = q - 1;
      }
      loadCart();
    }
  }

  void removeItem(String id) {
    GlobalData.removeFromCart(id);
    loadCart();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Your Cart"),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : cartItems.isEmpty
          ? const Center(child: Text("Your cart is empty."))
          : Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: cartItems.length,
              itemBuilder: (context, index) {
                final item = cartItems[index];

                final String id = item["_id"] ?? "";
                final String name = item["name"] ?? "";
                final double price =
                (item["price"] ?? 0).toDouble();
                final int quantity = item["quantity"] ?? 1;
                final bool inStock = item["inStock"] == true;

                return Card(
                  child: ListTile(
                    title: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          name,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        if (!inStock)
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.red,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              "OUT OF STOCK",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                      ],
                    ),

                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Price: \$${price.toStringAsFixed(2)}"),
                        SizedBox(height: 6),
                        Row(
                          children: [
                            // --- DECREMENT ---
                            IconButton(
                              icon: Icon(Icons.remove),
                              onPressed: () => decrementQty(id),
                            ),

                            Text(
                              quantity.toString(),
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),

                            // --- INCREMENT ---
                            IconButton(
                              icon: Icon(Icons.add),
                              onPressed: () => incrementQty(id),
                            ),
                          ],
                        ),
                      ],
                    ),

                    trailing: GestureDetector(
                      onTap: () => removeItem(id),
                      child: const Icon(Icons.delete, color: Colors.red),
                    ),
                  ),
                );
              },
            ),
          ),

          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 20, vertical: 16),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              boxShadow: const [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                  offset: Offset(0, -2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  "Subtotal: \$${getSubtotal().toStringAsFixed(2)}",
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  "Total (incl. tax): \$${getTotal().toStringAsFixed(2)}",
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.deepOrange,
                  ),
                ),

                if (hasOutOfStock())
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(
                      "Cannot checkout — cart contains OUT OF STOCK items.",
                      style: TextStyle(
                        color: Colors.red,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),

                const SizedBox(height: 14),

                ElevatedButton(
                  onPressed: hasOutOfStock()
                      ? null
                      : () {
                    // checkout logic soon
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.all(14),
                    disabledBackgroundColor: Colors.grey,
                  ),
                  child: const Text("Checkout"),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
