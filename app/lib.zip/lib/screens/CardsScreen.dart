// lib/screens/CardsScreen.dart

import 'package:flutter/material.dart';
import '../utils/getAPI.dart';
import '../utils/GlobalData.dart';
import 'CartScreen.dart';

class CardsScreen extends StatefulWidget {
  @override
  _CardsScreenState createState() => _CardsScreenState();
}

class _CardsScreenState extends State<CardsScreen> {
  List<dynamic> foods = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadFoods();
  }

  Future<void> loadFoods() async {
    final data = await APIService.getFoods();

    // Sort: in-stock first
    data.sort((a, b) {
      final bool aStock = a["inStock"] == true;
      final bool bStock = b["inStock"] == true;
      return bStock.toString().compareTo(aStock.toString());
    });

    setState(() {
      foods = data;
      isLoading = false;
    });
  }

  Future<void> deleteFood(String id) async {
    final success = await APIService.deleteFood(id);
    if (success) {
      loadFoods();
    }
  }

  void addFoodToCart(String foodId) {
    final food = foods.firstWhere((f) => f["_id"] == foodId);
    GlobalData.addToCart(food);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("${food["name"]} added to cart"),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("GrubGo", style: TextStyle(fontSize: 22)),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart, size: 28),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => CartScreen()),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.logout, size: 26),
            onPressed: () {
              GlobalData.clear();
              Navigator.pushNamedAndRemoveUntil(context, "/", (_) => false);
            },
          )
        ],
      ),

      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Column(
        children: [
          // header
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("${foods.length} food items loaded",
                    style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold)),
                ElevatedButton(
                  onPressed: openAddFoodPopup,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(
                        horizontal: 20, vertical: 12),
                  ),
                  child: Text("Add Food",
                      style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold)),
                )
              ],
            ),
          ),

          Expanded(
            child: ListView.builder(
              padding: EdgeInsets.all(12),
              itemCount: foods.length,
              itemBuilder: (context, index) {
                final food = foods[index];
                final id = food["_id"];
                final name = food["name"] ?? "";
                final price = (food["price"] ?? 0).toDouble();
                final category = food["category"] ?? "";
                final imageUrl = food["imageUrl"] ?? "";
                final inStock = food["inStock"] == true;

                return Stack(
                  children: [
                    Opacity(
                      opacity: inStock ? 1.0 : 0.35,
                      child: Card(
                        elevation: 3,
                        margin: EdgeInsets.symmetric(vertical: 8),
                        child: ListTile(
                          leading: _buildFoodImage(imageUrl),
                          title: Text(name,
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16)),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(category),
                              SizedBox(height: 4),
                              Text("\$${price.toStringAsFixed(2)}",
                                  style: TextStyle(
                                      color: Colors.deepOrange,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16))
                            ],
                          ),
                          trailing: Column(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              GestureDetector(
                                onTap: () => addFoodToCart(id),
                                child: Icon(Icons.add_shopping_cart,
                                    size: 26, color: Colors.blue),
                              ),
                              GestureDetector(
                                onTap: () => confirmDelete(id),
                                child: Icon(Icons.delete,
                                    size: 26, color: Colors.red),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    if (!inStock)
                      Positioned.fill(
                        child: Center(
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 12),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.85),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              "OUT OF STOCK",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.3),
                            ),
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
          )
        ],
      ),
    );
  }

  Widget _buildFoodImage(String url) {
    if (url.isEmpty) {
      return Icon(Icons.fastfood, size: 50, color: Colors.grey[600]);
    }

    return Image.network(
      url,
      width: 60,
      height: 60,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) =>
          Icon(Icons.fastfood, size: 50, color: Colors.grey[600]),
    );
  }

  void confirmDelete(String id) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Delete Food"),
        content: Text("Are you sure you want to delete this food item?"),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Cancel")),
          TextButton(
              onPressed: () async {
                Navigator.pop(context);
                await deleteFood(id);
              },
              child: Text("Delete", style: TextStyle(color: Colors.red))),
        ],
      ),
    );
  }

  void openAddFoodPopup() {
    String name = "", price = "", category = "", imageUrl = "";
    bool inStock = true;

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Add Food"),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                  decoration: InputDecoration(labelText: "Name"),
                  onChanged: (v) => name = v),
              TextField(
                  decoration: InputDecoration(labelText: "Price"),
                  keyboardType: TextInputType.number,
                  onChanged: (v) => price = v),
              TextField(
                  decoration: InputDecoration(labelText: "Category"),
                  onChanged: (v) => category = v),
              TextField(
                  decoration: InputDecoration(labelText: "Image URL"),
                  onChanged: (v) => imageUrl = v),
              SwitchListTile(
                title: Text("In Stock"),
                value: inStock,
                onChanged: (v) => inStock = v,
              )
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Cancel")),
          ElevatedButton(
              onPressed: () async {
                Navigator.pop(context);

                await APIService.createFood({
                  "name": name.trim(),
                  "price": double.tryParse(price.trim()) ?? 0,
                  "category": category.trim(),
                  "imageUrl": imageUrl.trim(),
                  "inStock": inStock,
                });

                loadFoods();
              },
              child: Text("Add"))
        ],
      ),
    );
  }
}
