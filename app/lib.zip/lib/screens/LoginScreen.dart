// lib/screens/LoginScreen.dart

import 'package:flutter/material.dart';
import '../utils/getAPI.dart';
import '../utils/GlobalData.dart';
import '../routes.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool isLoading = false;
  String errorMessage = "";

  void handleLogin() async {
    setState(() {
      isLoading = true;
      errorMessage = "";
    });

    final email = emailController.text.trim();
    final password = passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      setState(() {
        errorMessage = "Please enter email and password.";
        isLoading = false;
      });
      return;
    }

    final result = await APIService.login(email, password);

    setState(() {
      isLoading = false;
    });

    if (result != null) {
      // Login success 
      Navigator.pushReplacementNamed(context, AppRoutes.cards);
    } else {
      setState(() {
        errorMessage = "Invalid credentials. Try again.";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Login")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: emailController,
              decoration: const InputDecoration(labelText: "Email"),
            ),

            const SizedBox(height: 10),

            TextField(
              controller: passwordController,
              decoration: const InputDecoration(labelText: "Password"),
              obscureText: true,
            ),

            const SizedBox(height: 20),

            if (errorMessage.isNotEmpty)
              Text(
                errorMessage,
                style: const TextStyle(color: Colors.red),
              ),

            const SizedBox(height: 20),

            isLoading
                ? const CircularProgressIndicator()
                : ElevatedButton(
              onPressed: handleLogin,
              child: const Text("Login"),
            ),
          ],
        ),
      ),
    );
  }
}
