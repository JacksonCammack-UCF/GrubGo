class GlobalData {
  static String userId = '';
  static String firstName = '';
  static String lastName = '';
  static String loginName = '';
  static String password = '';


  static List<Map<String, dynamic>> cart = [];

  static void addToCart(Map<String, dynamic> food) {
    final String id = food["_id"]?.toString() ?? "";
    if (id.isEmpty) return;

    final index = cart.indexWhere((item) => item["_id"] == id);
    if (index >= 0) {
      final currentQty = cart[index]["quantity"] ?? 1;
      cart[index]["quantity"] = currentQty + 1;
    } else {
      final copy = Map<String, dynamic>.from(food);
      copy["quantity"] = 1;
      cart.add(copy);
    }
  }

  static void removeFromCart(String id) {
    cart.removeWhere((item) => item["_id"] == id);
  }

  static void clearCart() {
    cart.clear();
  }
  static void clear() {
    userId = '';
    firstName = '';
    lastName = '';
    loginName = '';
    password = '';
    cart.clear();
  }

  static void setUser(Map<String, dynamic> data) {
    Map<String, dynamic> user;

    if (data["login"] is List && data["login"].isNotEmpty) {
      user = data["login"][0];
    } else {
      user = data;
    }

    userId     = user["_id"]?.toString() ?? "";
    firstName  = user["firstName"] ?? "";
    lastName   = user["lastName"] ?? "";
    loginName  = user["username"] ?? "";
    password   = user["password"] ?? "";
  }

}
