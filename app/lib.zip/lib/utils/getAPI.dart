// lib/utils/getAPI.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'GlobalData.dart';

class APIService {
  static const String baseURL = "http://10.0.2.2:5050/api";

  // ---------------------------
  // LOGIN (matches your backend)
  // ---------------------------
  static Future<Map<String, dynamic>?> login(String email,
      String password) async {
    final url = Uri.parse("$baseURL/users/login");

    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "email": email,
          "password": password,
        }),
      );

      if (response.statusCode != 200) return null;

      final body = jsonDecode(response.body);

      // backend returns: { login: [ { user } ] }
      GlobalData.setUser(body);

      return body;
    } catch (e) {
      return null;
    }
  }

  // GET FOODS
  static Future<List<dynamic>> getFoods() async {
    final url = Uri.parse("$baseURL/foods");

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        return json["data"] ?? [];
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  // CREATE FOOD
  static Future<bool> createFood(Map<String, dynamic> body) async {
    final url = Uri.parse("$baseURL/foods");

    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(body),
      );

      return response.statusCode == 201 || response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  // DELETE FOOD
  static Future<bool> deleteFood(String id) async {
    final url = Uri.parse("$baseURL/foods/$id");

    try {
      final response = await http.delete(url);

      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  // CART

  // ADD
  static Future<bool> addToCart(String userId, String foodId) async {
    final url = Uri.parse("$baseURL/users/cart");

    try {
      final res = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "userId": userId,
          "foodId": foodId,
        }),
      );

      return res.statusCode == 200;
    } catch (e) {
      print("ADD CART ERROR: $e");
      return false;
    }
  }

  // REMOVE
  static Future<bool> removeFromCart(String userId, String foodId) async {
    final url = Uri.parse("$baseURL/users/removeFromCart");

    try {
      final res = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "userId": userId,
          "foodId": foodId,
        }),
      );

      return res.statusCode == 200;
    } catch (e) {
      print("REMOVE CART ERROR: $e");
      return false;
    }
  }

  // GET
  static Future<List<dynamic>> getCart(String userId) async {
    final url = Uri.parse("$baseURL/users/cart/$userId");

    try {
      final res = await http.get(url);

      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
      return [];
    } catch (e) {
      print("GET CART ERROR: $e");
      return [];
    }
  }
}
